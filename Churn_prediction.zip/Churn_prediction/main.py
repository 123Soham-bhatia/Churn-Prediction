# Importing necessary libraries
import pandas as pd
import matplotlib.pyplot as plt  # ✅ Added for plotting
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    confusion_matrix,
    ConfusionMatrixDisplay
)

# 1️⃣ Load the data
df = pd.read_csv('./customer_churn.csv')

# 2️⃣ Initial exploration
print("First 5 rows of the dataset:")
print(df.head())
print("\nDataset Info:")
print(df.info())

# 3️⃣ Data cleaning: Handle missing values (if any)
df = df.dropna()

# 4️⃣ Encoding categorical variables
label_encoders = {}
for column in df.select_dtypes(include=['object']).columns:
    le = LabelEncoder()
    df[column] = le.fit_transform(df[column])
    label_encoders[column] = le

# 5️⃣ Split features and target
# Assuming 'Churn' is the target column. Change if your dataset has a different name.
if 'Churn' not in df.columns:
    raise ValueError("'Churn' column not found in the dataset. Please check the target column name.")

X = df.drop('Churn', axis=1)
y = df['Churn']

# 6️⃣ Normalize numeric features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 7️⃣ Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

# 8️⃣ Logistic Regression model
model = LogisticRegression()
model.fit(X_train, y_train)

# 9️⃣ Predictions
y_pred = model.predict(X_test)

# 🔍 10️⃣ Evaluation metrics
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
conf_matrix = confusion_matrix(y_test, y_pred)

print(f"\n✅ Accuracy: {accuracy:.2f}")
print(f"✅ Precision: {precision:.2f}")
print(f"✅ Recall: {recall:.2f}")
print("\nConfusion Matrix:")
print(conf_matrix)

# 📊 Plot the confusion matrix
disp = ConfusionMatrixDisplay(confusion_matrix=conf_matrix)
disp.plot(cmap=plt.cm.Blues)  # Optional: nice blue color map

plt.title("Confusion Matrix")
plt.show()
